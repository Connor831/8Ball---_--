

function MagicResponse(){
let randomNumber = Math.floor(Math.random() * 11);
var input = document.getElementById('userQuestion').value;
document.getElementById('question').innerHTML = ('You Asked: ' + input);
console.log(randomNumber);

switch(randomNumber){
    case 0:
        console.log("Um from the way I see it HEll yes no denying it (っ＾▿＾)💨 ")
        document.getElementById('response').innerHTML = ("Um from the way I see it HEll yes no denying it (っ＾▿＾)💨");
        break;
        case 1:
        console.log("I'm curantly out at the minute so come back after lunch and ask again (͠◉_◉᷅ ) ")
        document.getElementById('response').innerHTML = ("I'm curantly out at the minute so come back after lunch and ask again (͠◉_◉᷅ )");
        break;
        case 2:
        console.log("Well I didn't react positivly to this one so I rather not say (̶◉͛‿◉̶) ")
        document.getElementById('response').innerHTML = ("Well I didn't react positivly to this one so I rather not say (̶◉͛‿◉̶)");
        break;
        case 3:
        console.log("It Is Certain")
        document.getElementById('response').innerHTML = ("It Is Certain");
        break;
        case 4:
        console.log("Um maybe just maybe ( ≖.≖) ")
        document.getElementById('response').innerHTML = ("Um maybe just maybe ( ≖.≖)");
        break;
        case 5:
        console.log("Reply Is a                   NO <(¬＿¬<)")
        document.getElementById('response').innerHTML = ("Reply Is a                             NO <(¬＿¬<)  ");
        break;
        case 6:
        console.log("Ya um don't you have work to do why are you playing with a kids toy? (⊙…⊙ ) ")
        document.getElementById('response').innerHTML = ("Ya um don't you have work to do why are you playing with a kids toy? (⊙…⊙ ) ");
        break;
        case 7:
        console.log("Outlook Not So Good")
        document.getElementById('response').innerHTML = ("Outlook Not So Good");
        break;
        case 8:
        console.log("Yes - Definitely")
        document.getElementById('response').innerHTML = ("Yes - Definitely");
        break;
        case 9:
        console.log("Most Likely")
        document.getElementById('response').innerHTML = ("Most Likely");
        break;
        case 10:
        console.log("Siri said No said no so I guess I will Say No (✌ﾟ∀ﾟ)☞")
        document.getElementById('response').innerHTML = ("Siri said No said no so I guess I will Say No (✌ﾟ∀ﾟ)☞ ");
        break;
}


}